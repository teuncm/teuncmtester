# ttest

[![PyPI - Version](https://img.shields.io/pypi/v/ttest.svg)](https://pypi.org/project/ttest)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ttest.svg)](https://pypi.org/project/ttest)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install ttest
```

## License

`ttest` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
